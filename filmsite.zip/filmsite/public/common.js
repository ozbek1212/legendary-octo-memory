function esc(s) {
  return String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

function ytId(url) {
  const m = String(url || '').match(/(?:youtu\.be\/|youtube\.com\/(?:watch\?v=|embed\/|shorts\/))([\w-]{11})/);
  return m ? m[1] : null;
}

function posterOf(m) {
  if (m.poster) return m.poster;
  const id = ytId(m.videoUrl);
  return id ? `https://img.youtube.com/vi/${id}/hqdefault.jpg` : '';
}

function playerHtml(url) {
  const id = ytId(url);
  if (id) {
    return `<iframe src="https://www.youtube-nocookie.com/embed/${id}" allowfullscreen allow="accelerometer; encrypted-media; picture-in-picture"></iframe>`;
  }
  if (/\.(mp4|webm|ogg)(\?.*)?$/i.test(url)) {
    return `<video controls preload="metadata" src="${esc(url)}"></video>`;
  }
  return `<iframe src="${esc(url)}" allowfullscreen></iframe>`;
}

function cardHtml(m) {
  const p = posterOf(m);
  return `<a class="card" href="/movie.html?id=${m.id}">
    <div class="thumb">${p ? `<img loading="lazy" src="${esc(p)}" alt="${esc(m.title)}">` : '<span>🎬</span>'}</div>
    <div class="info"><h3>${esc(m.title)}</h3>
    <p>${esc(m.year || '')}${m.year && m.category ? ' · ' : ''}${esc(m.category || '')}</p></div></a>`;
}
