const express = require('express');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const app = express();
const PORT = process.env.PORT || 3000;
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || 'admin123';
const DATA_DIR = path.join(__dirname, 'data');
const DATA_FILE = path.join(DATA_DIR, 'movies.json');

app.use(express.json({ limit: '100kb' }));
app.use(express.static(path.join(__dirname, 'public')));

/* ---------- Baza (JSON fayl) ---------- */
function seed() {
  const mk = (id, title, year, category, description, videoUrl, duration) => ({
    id, title, year, category, description, videoUrl, poster: '', duration,
    featured: false, views: 0, createdAt: new Date().toISOString(),
  });
  return [
    mk(1, 'Big Buck Bunny', 2008, 'Animasiya', 'Blender Foundation tərəfindən hazırlanmış pulsuz (Creative Commons) animasiya filmi.', 'https://www.youtube.com/watch?v=YE7VzlLtp-4', '10 dəq'),
    mk(2, 'Sintel', 2010, 'Fantastika', 'Blender Foundation-un açıq lisenziyalı qısametrajlı filmi.', 'https://www.youtube.com/watch?v=eRsGyueVLvQ', '15 dəq'),
    mk(3, 'Tears of Steel', 2012, 'Fantastika', 'Blender Foundation-un açıq lisenziyalı elmi-fantastik qısametrajlı filmi.', 'https://www.youtube.com/watch?v=R6MlUcmOul8', '12 dəq'),
  ].map((m, i) => (i === 0 ? { ...m, featured: true } : m));
}

function load() {
  try {
    return JSON.parse(fs.readFileSync(DATA_FILE, 'utf8'));
  } catch {
    const data = seed();
    save(data);
    return data;
  }
}

function save(data) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
  const tmp = DATA_FILE + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(data, null, 2));
  fs.renameSync(tmp, DATA_FILE);
}

let movies = load();

/* ---------- Admin sessiyası ---------- */
const sessions = new Map(); // token -> bitmə vaxtı
const attempts = new Map(); // ip -> { count, resetAt }
const SESSION_MS = 1000 * 60 * 60 * 8;

function parseCookies(req) {
  const out = {};
  (req.headers.cookie || '').split(';').forEach((p) => {
    const i = p.indexOf('=');
    if (i > 0) out[p.slice(0, i).trim()] = decodeURIComponent(p.slice(i + 1).trim());
  });
  return out;
}

function isAdmin(req) {
  const token = parseCookies(req).session;
  const exp = token && sessions.get(token);
  if (!exp) return false;
  if (exp < Date.now()) { sessions.delete(token); return false; }
  return true;
}

function requireAdmin(req, res, next) {
  if (!isAdmin(req)) return res.status(401).json({ error: 'Giriş tələb olunur' });
  next();
}

function safeEqual(a, b) {
  const ha = crypto.createHash('sha256').update(String(a)).digest();
  const hb = crypto.createHash('sha256').update(String(b)).digest();
  return crypto.timingSafeEqual(ha, hb);
}

app.post('/api/admin/login', (req, res) => {
  const ip = req.ip;
  const now = Date.now();
  const a = attempts.get(ip) || { count: 0, resetAt: now + 15 * 60 * 1000 };
  if (a.resetAt < now) { a.count = 0; a.resetAt = now + 15 * 60 * 1000; }
  if (a.count >= 8) return res.status(429).json({ error: 'Çox cəhd. 15 dəqiqə sonra yenidən yoxlayın.' });

  if (!safeEqual(req.body.password || '', ADMIN_PASSWORD)) {
    a.count++;
    attempts.set(ip, a);
    return res.status(401).json({ error: 'Şifrə yanlışdır' });
  }
  attempts.delete(ip);
  const token = crypto.randomBytes(32).toString('hex');
  sessions.set(token, now + SESSION_MS);
  res.setHeader('Set-Cookie', `session=${token}; HttpOnly; SameSite=Strict; Path=/; Max-Age=${SESSION_MS / 1000}`);
  res.json({ ok: true });
});

app.post('/api/admin/logout', (req, res) => {
  const token = parseCookies(req).session;
  if (token) sessions.delete(token);
  res.setHeader('Set-Cookie', 'session=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0');
  res.json({ ok: true });
});

app.get('/api/admin/me', (req, res) => res.json({ admin: isAdmin(req) }));

/* ---------- İctimai API ---------- */
app.get('/api/movies', (req, res) => {
  const { q = '', category = '' } = req.query;
  const term = String(q).trim().toLowerCase();
  let list = movies.filter((m) =>
    (!term || m.title.toLowerCase().includes(term) || (m.description || '').toLowerCase().includes(term)) &&
    (!category || m.category === category));
  list = [...list].sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  res.json({
    movies: list,
    categories: [...new Set(movies.map((m) => m.category).filter(Boolean))].sort(),
  });
});

app.get('/api/movies/:id', (req, res) => {
  const m = movies.find((x) => x.id === Number(req.params.id));
  if (!m) return res.status(404).json({ error: 'Film tapılmadı' });
  m.views++;
  save(movies);
  const related = movies.filter((x) => x.id !== m.id && x.category === m.category).slice(0, 6);
  res.json({ movie: m, related });
});

/* ---------- Admin API ---------- */
function clean(body) {
  const str = (v, max) => String(v ?? '').trim().slice(0, max);
  const m = {
    title: str(body.title, 200),
    year: Number(body.year) || null,
    category: str(body.category, 60),
    description: str(body.description, 3000),
    videoUrl: str(body.videoUrl, 1000),
    poster: str(body.poster, 1000),
    duration: str(body.duration, 30),
    featured: !!body.featured,
  };
  if (!m.title) return { error: 'Ad mütləqdir' };
  if (!/^https?:\/\//i.test(m.videoUrl)) return { error: 'Video linki http:// və ya https:// ilə başlamalıdır' };
  if (m.poster && !/^https?:\/\//i.test(m.poster)) return { error: 'Poster linki http:// və ya https:// ilə başlamalıdır' };
  return { m };
}

app.get('/api/admin/stats', requireAdmin, (req, res) => {
  res.json({
    total: movies.length,
    views: movies.reduce((s, m) => s + m.views, 0),
    categories: new Set(movies.map((m) => m.category).filter(Boolean)).size,
    top: [...movies].sort((a, b) => b.views - a.views).slice(0, 5).map((m) => ({ id: m.id, title: m.title, views: m.views })),
  });
});

app.post('/api/admin/movies', requireAdmin, (req, res) => {
  const { m, error } = clean(req.body);
  if (error) return res.status(400).json({ error });
  const id = movies.reduce((mx, x) => Math.max(mx, x.id), 0) + 1;
  const movie = { id, ...m, views: 0, createdAt: new Date().toISOString() };
  movies.push(movie);
  save(movies);
  res.status(201).json(movie);
});

app.put('/api/admin/movies/:id', requireAdmin, (req, res) => {
  const i = movies.findIndex((x) => x.id === Number(req.params.id));
  if (i < 0) return res.status(404).json({ error: 'Film tapılmadı' });
  const { m, error } = clean(req.body);
  if (error) return res.status(400).json({ error });
  movies[i] = { ...movies[i], ...m };
  save(movies);
  res.json(movies[i]);
});

app.delete('/api/admin/movies/:id', requireAdmin, (req, res) => {
  const before = movies.length;
  movies = movies.filter((x) => x.id !== Number(req.params.id));
  if (movies.length === before) return res.status(404).json({ error: 'Film tapılmadı' });
  save(movies);
  res.json({ ok: true });
});

app.listen(PORT, () => {
  console.log(`Sayt işləyir: http://localhost:${PORT}`);
  console.log(`Admin panel:  http://localhost:${PORT}/admin.html`);
  if (!process.env.ADMIN_PASSWORD) console.log('DİQQƏT: standart şifrə (admin123) istifadə olunur. ADMIN_PASSWORD təyin edin!');
});
