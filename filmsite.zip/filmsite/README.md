# FilmBox — idarə panelli film saytı

Sadə, pulsuz film saytı: ictimai səhifələr (axtarış, kateqoriya, oxşar filmlər, oynadıcı) və şifrə ilə qorunan **idarə paneli** (film əlavə et / redaktə et / sil, statistika).

## Yerli işə salma

```bash
npm install
ADMIN_PASSWORD=sizin_guclu_sifreniz npm start
```

- Sayt: http://localhost:3000
- Admin panel: http://localhost:3000/admin.html

Windows (PowerShell):

```powershell
$env:ADMIN_PASSWORD="sizin_guclu_sifreniz"; npm start
```

> `ADMIN_PASSWORD` təyin etməsəniz standart şifrə `admin123` olur. İnternetə çıxarmazdan əvvəl mütləq dəyişin!

## Pulsuz yerləşdirmə (hosting)

Render.com, Railway, Fly.io və ya Koyeb kimi Node.js dəstəkləyən pulsuz planlardan birində:

1. Qovluğu GitHub-a yükləyin.
2. Yeni "Web Service" yaradın, Build: `npm install`, Start: `npm start`.
3. Environment dəyişəni əlavə edin: `ADMIN_PASSWORD`.

Qeyd: bəzi pulsuz planlarda fayl sistemi müvəqqətidir (`data/movies.json` yenidən deploy zamanı sıfırlana bilər). Daimi saxlama üçün "persistent disk" əlavə edin və ya JSON bazanı xarici pulsuz bazaya (məs. Supabase) keçirin.

## Video əlavə etmə

Admin paneldə "Video linki" sahəsinə bunlardan birini yazın:

- YouTube linki (avtomatik oynadıcı və poster)
- Birbaşa `.mp4` / `.webm` linki
- İcazə verilən başqa platformanın embed linki

## Hüquqi qeyd

Yalnız **qanuni məzmun** yerləşdirin: öz çəkdiyiniz videolar, Creative Commons / ictimai domen filmləri (məs. Blender Foundation filmləri, archive.org-dakı ictimai domen filmləri) və ya sahibinin icazə verdiyi məzmun. Başqasının müəllif hüququ olan filmlərin icazəsiz yayımlanması qanunsuzdur və saytınız bağlana bilər.

## Quruluş

```
server.js          — Express server və API
data/movies.json   — baza (ilk işə salmada avtomatik yaranır)
public/            — index, movie, admin səhifələri, CSS, JS
```
